<details>
<summary>1.0.0 </summary>

* Now has sounds straight from JSR.
</details>
<details>
<summary>0.9.1 </summary>

* I forgot the asset bundle, oops
</details>
<details>
<summary>0.9.0 </summary>

* Initial release
</details>