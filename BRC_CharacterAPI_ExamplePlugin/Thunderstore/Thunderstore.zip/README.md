# DisableAnnoyingCutscenes
Disables police cutscenes every time you get a new heat level.
## Future plans
Also disable the following cutscenes
* Getting in and out of constume swap
* Dance after selecting different character
* Animation and showcase of new graffiti (this one might not come) 