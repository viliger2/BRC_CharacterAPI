# Beat
Beat is here to join Bomb Rush Crew! Gum sadly couldn't make it.
![Beat](https://raw.githubusercontent.com/viliger2/BRC_CharacterAPI/main/BRC_CharacterAPI_ExamplePlugin/ThunderstoreImages/screenshots.jpeg)
## Known issues
* Phone and spaycan have wonky positions, mainly matters for phone since it is used for taking pictures
* Boots are a bit small for skates
* Beat impales himself on bike's seat