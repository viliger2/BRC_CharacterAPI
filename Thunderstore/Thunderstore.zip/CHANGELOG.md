<details>
<summary>0.5.01 </summary>

* Readme fix because I love markdown.
</details>
<details>
<summary>0.5.0 </summary>

* Initial release
</details>